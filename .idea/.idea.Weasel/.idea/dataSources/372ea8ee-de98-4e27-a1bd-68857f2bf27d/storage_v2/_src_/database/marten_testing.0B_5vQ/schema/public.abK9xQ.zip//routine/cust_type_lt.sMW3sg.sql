create function cust_type_lt(cust_type, cust_type) returns boolean
    immutable
    language sql
as
$$
SELECT cust_type_compare($1, $2) = -1
$$;

alter function cust_type_lt(cust_type, cust_type) owner to postgres;


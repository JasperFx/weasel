create function mt_insert_user(doc jsonb, docdotnettype character varying, docid uuid, docversion uuid) returns uuid
    language plpgsql
as
$$
BEGIN
INSERT INTO public.mt_doc_user ("data", "mt_dotnet_type", "id", "mt_version", mt_last_modified) VALUES (doc, docDotNetType, docId, docVersion, transaction_timestamp());

  RETURN docVersion;
END;
$$;

alter function mt_insert_user(jsonb, varchar, uuid, uuid) owner to postgres;


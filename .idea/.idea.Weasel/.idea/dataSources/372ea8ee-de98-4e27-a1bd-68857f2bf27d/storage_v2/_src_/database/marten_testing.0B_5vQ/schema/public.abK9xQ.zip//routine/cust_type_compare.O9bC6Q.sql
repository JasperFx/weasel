create function cust_type_compare(cust_type, cust_type) returns integer
    language plpgsql
as
$$
BEGIN
                        RETURN strcmp($1::text, $2::text);
                    END;
$$;

alter function cust_type_compare(cust_type, cust_type) owner to postgres;


create function mt_update_user(doc jsonb, docdotnettype character varying, docid uuid, docversion uuid) returns uuid
    language plpgsql
as
$$
DECLARE
  final_version uuid;
BEGIN
  UPDATE public.mt_doc_user SET "data" = doc, "mt_dotnet_type" = docDotNetType, "mt_version" = docVersion, mt_last_modified = transaction_timestamp() where id = docId;

  SELECT mt_version FROM public.mt_doc_user into final_version WHERE id = docId ;
  RETURN final_version;
END;
$$;

alter function mt_update_user(jsonb, varchar, uuid, uuid) owner to postgres;


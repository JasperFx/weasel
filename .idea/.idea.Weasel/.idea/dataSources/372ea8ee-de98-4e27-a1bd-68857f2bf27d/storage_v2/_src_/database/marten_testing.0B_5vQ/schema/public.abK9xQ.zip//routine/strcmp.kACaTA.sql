create function strcmp(text, text) returns integer
    language sql
as
$$
SELECT CASE WHEN $1 < $2 THEN -1
                        WHEN $1 > $2 THEN 1
                        ELSE 0 END;
$$;

alter function strcmp(text, text) owner to postgres;

